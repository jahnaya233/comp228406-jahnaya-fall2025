package guiapp.model;

public class Player {
    private int playerId;
    private String firstName;
    private String lastName;
    private String address;
    private String postalCode;
    private String province;
    private String phoneNumber;

public int getPlayerId() {
    return playerId;
}

public void setPlayerId(int playerId) {
    this.playerId = playerId;
}
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
    return lastName;
    }

    public void setLastName(String lastName) {
    this.lastName = lastName;
    }

    public String getAddress() {
    return address;
    }

    public void setAddress(String address) {
    this.address = address;
    }

    public String getPostalCode() {
        return postalCode;

    }
    public void setPostalCode(String postalCode) {
    this.postalCode = postalCode;
    }

    public String getProvince() {
    return province;
    }
    public void setProvince(String province) {
    this.province = province;
    }

    public String getPhoneNumber() {
    return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
    }
}